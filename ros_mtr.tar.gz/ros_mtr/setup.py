from setuptools import setup

package_name = 'ros_mtr'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='014315366',
    maintainer_email='rahukand@gmail.com',
    description='TODO: Package description',
    license='Apache-2.0',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'print_sample = ros_mtr.print_sample:print_inference',
            'run_inference_node = ros_mtr.print_sample:main',
        ],
    },
)
