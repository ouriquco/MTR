import logging
import pprint
from mtr.datasets import WaymoDataset
from mtr.config import cfg_from_yaml_file, cfg 
from pathlib import Path

def print_inference():
    logger = logging.getLogger("MTR_dataloader")
    CGF_PATH = "/data/cmpe258-sp24/017553289/cmpe249/MTR/tools/cfgs/waymo/mtr+20_percent_data.yaml" 

    config = cfg_from_yaml_file(CGF_PATH, cfg)
    config.ROOT_DIR = Path('/data/cmpe258-sp24/017553289/cmpe249/MTR/')
    #pprint.pp(config)

    dataset = WaymoDataset(config.DATA_CONFIG, training=False, logger=logger) 
    DATA_SAMPLE = dataset.collate_batch([dataset[0]])['input_dict']
    pprint.pp(DATA_SAMPLE)



import rclpy
from rclpy.node import Node

from std_msgs.msg import String


class MinimalPublisher(Node):

    def __init__(self):
        super().__init__('minimal_publisher')
        self.publisher_ = self.create_publisher(String, 'topic', 10)
        timer_period = 2  # seconds
        self.timer = self.create_timer(timer_period, self.timer_callback)
        self.i = 0

    def timer_callback(self):
        print("This is message %d" % self.i)
        self.i += 1
        print_inference()


def main(args=None):
    rclpy.init(args=args)

    minimal_publisher = MinimalPublisher()

    rclpy.spin(minimal_publisher)

    # Destroy the node explicitly
    # (optional - otherwise it will be done automatically
    # when the garbage collector destroys the node object)
    minimal_publisher.destroy_node()
    rclpy.shutdown()



if __name__=='__main__': 
    print_inference()
